import { useEffect, useMemo, useRef, useState } from 'react'
import L from 'leaflet'
import { MapContainer, Marker, Polyline, TileLayer, useMap } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'

const RECALCULATE_DISTANCE_METERS = 50
const RECALCULATE_COOLDOWN_MS = 30000
const EMPTY_COORDINATES = []

function getRouteProgress(location, coordinates) {
  if (!location || coordinates.length < 2) return { distanceFromRoute: Infinity, progress: 0 }

  const latitudeScale = 110540
  const longitudeScale = 111320 * Math.cos(location.latitude * Math.PI / 180)
  const point = { x: location.longitude * longitudeScale, y: location.latitude * latitudeScale }
  let distanceFromRoute = Infinity
  let progress = 0
  let distanceBeforeSegment = 0

  for (let index = 1; index < coordinates.length; index += 1) {
    const previous = coordinates[index - 1]
    const current = coordinates[index]
    const start = { x: previous[0] * longitudeScale, y: previous[1] * latitudeScale }
    const end = { x: current[0] * longitudeScale, y: current[1] * latitudeScale }
    const segmentX = end.x - start.x
    const segmentY = end.y - start.y
    const segmentLength = Math.hypot(segmentX, segmentY)
    const ratio = segmentLength === 0 ? 0 : Math.max(0, Math.min(1, ((point.x - start.x) * segmentX + (point.y - start.y) * segmentY) / (segmentLength ** 2)))
    const nearest = { x: start.x + ratio * segmentX, y: start.y + ratio * segmentY }
    const distance = Math.hypot(point.x - nearest.x, point.y - nearest.y)

    if (distance < distanceFromRoute) {
      distanceFromRoute = distance
      progress = distanceBeforeSegment + ratio * segmentLength
    }
    distanceBeforeSegment += segmentLength
  }

  return { distanceFromRoute, progress }
}

function formatDistance(meters) {
  if (!Number.isFinite(meters)) return '--'
  if (meters < 1000) return `${Math.max(0, Math.round(meters / 10) * 10)} m`
  return `${(meters / 1000).toFixed(meters >= 10000 ? 0 : 1)} km`
}

function formatDuration(seconds) {
  const minutes = Math.max(1, Math.round(seconds / 60))
  if (minutes >= 60) return `${Math.floor(minutes / 60)} h ${minutes % 60} min`
  return `${minutes} min`
}

function describeManeuver(step) {
  const { type, modifier } = step.maneuver
  const road = step.name ? ` en ${step.name}` : ''
  const directions = {
    left: 'a la izquierda',
    right: 'a la derecha',
    'slight left': 'ligeramente a la izquierda',
    'slight right': 'ligeramente a la derecha',
    'sharp left': 'cerrado a la izquierda',
    'sharp right': 'cerrado a la derecha',
    straight: 'recto',
    uturn: 'en U',
  }
  const direction = directions[modifier]

  if (type === 'arrive') return 'Has llegado a tu destino'
  if (type === 'depart') return `Inicia la marcha${road}`
  if (type === 'roundabout' || type === 'rotary' || type === 'roundabout turn') return `Toma la rotonda${direction ? ` ${direction}` : ''}${road}`
  if (type === 'merge') return `Incorpórate${direction ? ` ${direction}` : ''}${road}`
  if (type === 'on ramp') return `Toma la entrada${road}`
  if (type === 'off ramp') return `Toma la salida${road}`
  if (type === 'fork') return `En la bifurcación, mantente ${direction || 'en la vía indicada'}${road}`
  if (type === 'end of road') return `Al final de la vía, gira ${direction || 'según la señalización'}${road}`
  if (type === 'new name' || type === 'continue') return `Continúa${road}`
  if (direction) return `Gira ${direction}${road}`
  return `Continúa${road}`
}

function createMarkerIcon(className) {
  return L.divIcon({
    className: `navigation-marker ${className}`,
    html: '<span></span>',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  })
}

const vehicleIcon = createMarkerIcon('vehicle-marker')
const destinationIcon = createMarkerIcon('destination-marker')

function MapViewport({ center, followVehicle, location, recenterKey }) {
  const map = useMap()
  const previousRecenterKey = useRef(recenterKey)

  useEffect(() => {
    if (followVehicle && location) map.panTo(center, { animate: true, duration: 0.45 })
    else if (location && recenterKey !== previousRecenterKey.current) map.setView(center, Math.max(map.getZoom(), 15), { animate: true })
    previousRecenterKey.current = recenterKey
  }, [center, followVehicle, location, map, recenterKey])

  return null
}

function FitRoute({ positions, route }) {
  const map = useMap()

  useEffect(() => {
    if (route && positions.length > 1) map.fitBounds(positions, { padding: [42, 42], maxZoom: 15, animate: true })
  }, [map, positions, route])

  return null
}

function NavigationView({ location, speed, locationStatus, requestLocation }) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [destination, setDestination] = useState(null)
  const [route, setRoute] = useState(null)
  const [searchStatus, setSearchStatus] = useState('')
  const [routeStatus, setRouteStatus] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [isRouting, setIsRouting] = useState(false)
  const [followVehicle, setFollowVehicle] = useState(true)
  const [recenterKey, setRecenterKey] = useState(0)
  const routeController = useRef(null)
  const searchController = useRef(null)
  const routeRequestRef = useRef(null)
  const routeBusy = useRef(false)
  const lastRecalculation = useRef(0)
  const gpsActive = Boolean(location && locationStatus === 'Señal GPS activa')
  const center = useMemo(() => location ? [location.latitude, location.longitude] : [40.4168, -3.7038], [location])
  const coordinates = route?.geometry?.coordinates || EMPTY_COORDINATES
  const latLngRoute = useMemo(() => coordinates.map(([longitude, latitude]) => [latitude, longitude]), [coordinates])
  const routeProgress = useMemo(() => getRouteProgress(location, coordinates), [location, coordinates])
  const maneuver = (() => {
    if (!route || !route.steps?.length) return null
    let stepEnd = 0
    for (const step of route.steps) {
      stepEnd += step.distance
      if (stepEnd >= routeProgress.progress + 12 && step.maneuver.type !== 'depart') {
        return { step, distance: stepEnd - routeProgress.progress }
      }
    }
    return null
  })()

  const calculateRoute = async (target, origin, automatic = false) => {
    if (!target || !origin || routeBusy.current) return
    routeBusy.current = true
    routeController.current?.abort()
    const controller = new AbortController()
    routeController.current = controller
    setIsRouting(true)
    if (!automatic) setRouteStatus('Calculando ruta…')

    try {
      const coordinatesText = `${origin.longitude},${origin.latitude};${target.lon},${target.lat}`
      const response = await fetch(`https://router.project-osrm.org/route/v1/driving/${coordinatesText}?overview=full&geometries=geojson&steps=true`, { signal: controller.signal })
      if (!response.ok) throw new Error('No se pudo conectar con el servicio de rutas.')
      const data = await response.json()
      if (data.code !== 'Ok' || !data.routes?.length) throw new Error('No se encontró una ruta en coche para ese destino.')
      const selectedRoute = data.routes[0]
      const steps = selectedRoute.legs.flatMap((leg) => leg.steps)
      setRoute({ ...selectedRoute, steps })
      setRouteStatus(automatic ? 'Ruta actualizada' : '')
      lastRecalculation.current = Date.now()
    } catch (error) {
      if (error.name !== 'AbortError') {
        setRouteStatus(!navigator.onLine
          ? 'Sin conexión. La ruta se conserva y se puede recalcular al volver a conectarse.'
          : error.message || 'No se pudo calcular la ruta. Inténtalo de nuevo.')
      }
    } finally {
      if (routeController.current === controller) {
        routeBusy.current = false
        setIsRouting(false)
      }
    }
  }

  useEffect(() => {
    routeRequestRef.current = calculateRoute
  })

  useEffect(() => () => {
    routeController.current?.abort()
    searchController.current?.abort()
  }, [])

  useEffect(() => {
    if (!gpsActive || !destination) return
    if (!route) {
      if (routeStatus === 'Esperando una posición GPS para calcular la ruta.') routeRequestRef.current?.(destination, location)
      return
    }
    if (routeProgress.distanceFromRoute <= RECALCULATE_DISTANCE_METERS) return
    if (Date.now() - lastRecalculation.current < RECALCULATE_COOLDOWN_MS) return
    routeRequestRef.current?.(destination, location, true)
  }, [destination, gpsActive, location, route, routeProgress.distanceFromRoute, routeStatus])

  const searchDestination = async (event) => {
    event.preventDefault()
    const searchTerm = query.trim()
    if (!searchTerm) return
    searchController.current?.abort()
    const controller = new AbortController()
    searchController.current = controller
    setIsSearching(true)
    setSearchStatus('Buscando destino…')
    setResults([])

    try {
      const params = new URLSearchParams({ q: searchTerm, format: 'json', limit: '5', 'accept-language': 'es' })
      const response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, { signal: controller.signal, headers: { Accept: 'application/json' } })
      if (!response.ok) throw new Error('El buscador de destinos no está disponible ahora.')
      const data = await response.json()
      setResults(data)
      setSearchStatus(data.length ? '' : 'No se encontraron destinos. Prueba con otra dirección o localidad.')
    } catch (error) {
      if (error.name !== 'AbortError') setSearchStatus(!navigator.onLine ? 'Sin conexión. Comprueba Internet e inténtalo de nuevo.' : error.message || 'No se pudo buscar el destino.')
    } finally {
      if (searchController.current === controller) setIsSearching(false)
    }
  }

  const selectDestination = (result) => {
    const target = { lat: Number(result.lat), lon: Number(result.lon), name: result.display_name }
    setDestination(target)
    setResults([])
    setQuery('')
    setRoute(null)
    setFollowVehicle(false)
    if (!location || !gpsActive) {
      setRouteStatus('Esperando una posición GPS para calcular la ruta.')
      return
    }
    calculateRoute(target, location)
  }

  const cancelRoute = () => {
    routeController.current?.abort()
    routeBusy.current = false
    setIsRouting(false)
    setDestination(null)
    setRoute(null)
    setRouteStatus('')
    setResults([])
    setSearchStatus('')
    lastRecalculation.current = 0
  }

  const statusLabel = !window.isSecureContext
    ? 'La navegación GPS requiere HTTPS.'
    : gpsActive
      ? locationStatus
      : locationStatus || 'Esperando señal GPS'

  return (
    <section className="feature-view navigation-view">
      <div className="feature-heading"><div><p className="eyebrow">EN RUTA</p><h1>Navegación</h1></div><span className={`live-tag ${gpsActive ? 'is-live' : ''}`}><span />{gpsActive ? 'GPS ACTIVO' : 'GPS INACTIVO'}</span></div>
      <form className="navigation-search" onSubmit={searchDestination}>
        <label className="sr-only" htmlFor="navigation-destination">¿A dónde quieres ir?</label>
        <input id="navigation-destination" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="¿A dónde quieres ir?" autoComplete="off" />
        <button type="submit" disabled={!query.trim() || isSearching}>{isSearching ? 'Buscando…' : 'Buscar'}</button>
      </form>
      {searchStatus && <p className="navigation-message" role="status">{searchStatus}</p>}
      {results.length > 0 && <ul className="navigation-results" aria-label="Resultados de búsqueda">{results.map((result) => <li key={result.place_id}><button type="button" onClick={() => selectDestination(result)}><strong>{result.name || result.display_name.split(',')[0]}</strong><span>{result.display_name}</span></button></li>)}</ul>}
      {routeStatus && <p className={`navigation-message ${routeStatus.includes('Sin conexión') || routeStatus.includes('no se encontró') ? 'is-error' : ''}`} role="status">{routeStatus}</p>}
      <div className="navigation-map-layout">
        <div className="map-frame navigation-map">
          <MapContainer center={center} zoom={location ? 15 : 5} scrollWheelZoom className="leaflet-navigation-map">
            <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <MapViewport center={center} followVehicle={followVehicle} location={location} recenterKey={recenterKey} />
            <FitRoute positions={latLngRoute} route={route} />
            {location && <Marker position={center} icon={vehicleIcon} title="Posición GPS" />}
            {destination && <Marker position={[destination.lat, destination.lon]} icon={destinationIcon} title={destination.name} />}
            {latLngRoute.length > 0 && <Polyline positions={latLngRoute} pathOptions={{ color: 'var(--accent)', weight: 6, opacity: 0.88 }} />}
          </MapContainer>
          <div className="navigation-map-controls">
            <button type="button" onClick={() => { setFollowVehicle(false); setRecenterKey((current) => current + 1) }} disabled={!location}>Recentrar</button>
            <button className={followVehicle ? 'is-selected' : ''} type="button" onClick={() => setFollowVehicle((current) => !current)} aria-pressed={followVehicle}>Seguir vehículo</button>
          </div>
          {!location && <div className="navigation-map-overlay"><strong>{statusLabel}</strong>{window.isSecureContext && <button className="location-request-button" type="button" onClick={() => requestLocation(true)}>Solicitar ubicación</button>}</div>}
        </div>
        <aside className="navigation-info" aria-live="polite">
          <div className="navigation-destination"><span className="eyebrow">DESTINO</span><strong>{destination?.name || 'Sin destino seleccionado'}</strong></div>
          {route && <>
            <div className="navigation-route-stats"><strong>{formatDistance(route.distance)}</strong><span>{formatDuration(route.duration)}</span></div>
            <div className="navigation-next-turn"><span className="eyebrow">PRÓXIMA INDICACIÓN</span><strong>{maneuver ? `${describeManeuver(maneuver.step)} en ${formatDistance(maneuver.distance)}` : 'Has llegado a tu destino'}</strong></div>
          </>}
          <div className="navigation-gps-status"><span className={`status-dot ${gpsActive ? 'active' : ''}`} />{statusLabel}</div>
          {speed != null && gpsActive && <span className="navigation-speed"><strong>{Math.round(speed)}</strong> km/h</span>}
          {destination && <button className="navigation-cancel" type="button" onClick={cancelRoute}>Cancelar ruta</button>}
          {isRouting && <span className="navigation-loading">{route ? 'Actualizando ruta…' : 'Calculando ruta…'}</span>}
        </aside>
      </div>
    </section>
  )
}

export default NavigationView
